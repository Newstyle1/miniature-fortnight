export default function ShippingRoutes() {
  return (
    <div style={{ backgroundColor: '#000', color: '#FFD700', minHeight: '100vh', padding: '2rem' }}>
      <h1>Shipping Routes</h1>
      <p>We ship globally to Europe, the Americas, the Middle East, and Africa.</p>
      <p>Estimated delivery times range from 7 to 30 days depending on destination.</p>
    </div>
  );
}