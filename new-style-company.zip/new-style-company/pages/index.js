import Head from 'next/head';
import Link from 'next/link';

export default function Home() {
  return (
    <div style={{ backgroundColor: '#000', color: '#FFD700', minHeight: '100vh', padding: '2rem' }}>
      <Head>
        <title>New Style Company</title>
      </Head>
      <header style={{ textAlign: 'center', marginBottom: '2rem' }}>
        <div style={{
          width: 100, height: 100, borderRadius: '50%',
          backgroundColor: '#000', border: '2px solid #FFD700',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          margin: '0 auto', fontSize: 36, fontWeight: 'bold', color: '#FFD700'
        }}>
          NS
        </div>
        <h1>Welcome to New Style Company</h1>
        <p>Your gateway to global trade and logistics from China</p>
        <nav style={{ marginTop: '1rem' }}>
          <Link href="/services">Services</Link> |{' '}
          <Link href="/routes">Shipping Routes</Link> |{' '}
          <Link href="/contact">Contact Us</Link>
        </nav>
      </header>
    </div>
  );
}