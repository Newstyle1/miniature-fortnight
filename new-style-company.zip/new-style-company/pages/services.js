export default function Services() {
  return (
    <div style={{ backgroundColor: '#000', color: '#FFD700', minHeight: '100vh', padding: '2rem' }}>
      <h1>Our Services</h1>
      <ul>
        <li>International trade and sourcing from China</li>
        <li>Sea freight and air cargo</li>
        <li>Customs clearance</li>
        <li>Logistics and supply chain support</li>
      </ul>
    </div>
  );
}