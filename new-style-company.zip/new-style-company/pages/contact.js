export default function Contact() {
  return (
    <div style={{ backgroundColor: '#000', color: '#FFD700', minHeight: '100vh', padding: '2rem' }}>
      <h1>Contact Us</h1>
      <form style={{ display: 'flex', flexDirection: 'column', maxWidth: 400 }}>
        <label>Name:<input type="text" name="name" /></label>
        <label>Email:<input type="email" name="email" /></label>
        <label>Message:<textarea name="message"></textarea></label>
        <button type="submit" style={{ marginTop: '1rem' }}>Send</button>
      </form>
    </div>
  );
}